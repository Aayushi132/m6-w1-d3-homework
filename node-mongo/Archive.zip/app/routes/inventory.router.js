module.exports = function (app) {
  var inventories = require("../controllers/inventory.controller.js");
  console.log("inventories123", inventories);

  app.post("/api/inventory", inventories.createInventory);
  app.get("/api/inventory/:id", inventories.getInventory);
  app.get("/api/inventories", inventories.inventories);
  app.put("/api/inventory", inventories.updateInventory);
  app.delete("/api/inventory/:id", inventories.deleteInventory);
};
